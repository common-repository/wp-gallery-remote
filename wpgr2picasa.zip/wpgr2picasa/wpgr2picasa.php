<?php

require_once 'libcurlemu/libcurlemu.inc.php';
require_once 'bloggerClass/class.bloggerclient.php';
require_once 'Zend/Loader.php';
Zend_Loader::loadClass('Zend_Gdata_Photos');
Zend_Loader::loadClass('Zend_Gdata_ClientLogin');
Zend_Loader::loadClass('Zend_Gdata_AuthSub');
require_once 'MyMediaVariableSource.php';

// config - CHAMGE TO YOUR NEEDS
$wp_host = 'test.wordpress.com';
$wp_username = "wordpress_user";
$wp_password = "wordpres_password";
$picasa_username = "picasa_user";
$picasa_password = "picasa_password";
$slideshow_width = '400';
$slideshow_height = '267';
$gallery_host = 'http://galleryhost.com/main.php';

// login to wordpress
echo "=> logging in to wordpress blog\n";
$b = new bloggerclient($wp_host, $wp_username, $wp_password);

// login to picasa
echo "=> logging in to picasa webalbums\n";
$serviceName = Zend_Gdata_Photos::AUTH_SERVICE_NAME;
$client = Zend_Gdata_ClientLogin::getHttpClient($picasa_username, $picasa_password, $serviceName);
$gp = new Zend_Gdata_Photos($client, "Google-DevelopersGuide-1.0");

// get posts of first blog
echo "=> retrieving blog posts\n";
$blogs = $b->getUsersBlogs();
$blog_id = $blogs[0]['blogid'];
$posts = $b->getRecentPosts($blog_id, 999);

// start digging in the dirt - accessing gallery via remote protocol
echo "=> fetching gallery albums\n";
$galleries = array( array(url => $gallery_host) );
$images = array();
$album_list = array();
fetch_albums(0, false);

foreach ($posts as $post) {
	$new_content = preg_replace_callback('/\{wp-gallery-remote:[\s;]*(([a-z]+[a-z0-9]*[\s]*=[\s]*[a-z0-9,|:\s]*[\s]*;[\s;]*)*)\}/i', 
						'parse_wpgr_tags_callback',
						$post['content']);

	if ($new_content != $post['content']) {
		echo '=> updating post: ' . $post['postid'] . "\n";
		$b->editPost($post['postid'], $new_content, true);
	}
}

// callback function which gets called for each wp-gallery-remote tag in a post
function parse_wpgr_tags_callback($matches) {
	global $images;
	global $album_list;
	global $query;
	global $gp;
	global $picasa_username;
	global $slideshow_width;
	global $slideshow_height;
	
	$gallery_id = 0;
	
	// convert parameters into array
    $param_pairs = explode(';', $matches[1]);
    $params = array();
    foreach ($param_pairs as $pair) {
      list($key, $value) = explode('=', $pair);
      $params[trim($key)] = trim($value);
    }

    // select gallery
	if (!array_key_exists('gallery', $params)) {
	  $params['gallery'] = 0;
	}
	
    if (!array_key_exists('rootalbum', $params)) { $params['rootalbum'] = 0; }
    $current_album = $params['rootalbum'];
    $current_album_idx = array_search($current_album, $album_list[$gallery_id]['album']['name']);
    
    echo '==> transferring pictures from album: ' . $album_list[$gallery_id]['album']['title'][$current_album_idx] . "\n";

    $image_filter = array();
    $imagefilterActive = array_key_exists('imagefilter', $params);
    if ($imagefilterActive) {
    	echo '===> image filter: ON' . "\n";
      list($image_filter['type'], $image_filter['filter']) = explode(':', $params['imagefilter']);        
      $image_filter['filter'] = explode(',', $image_filter['filter']);
    }
    
	fetch_images($params['rootalbum'], false);
	
	// retrieve album
	$album_name = ereg_replace('[^A-Za-z0-9]', '', $album_list[$gallery_id]['album']['title'][$current_album_idx]);
	$albumQuery = $gp->newAlbumQuery();
	$albumQuery->setUser($picasa_username);
	$albumQuery->setAlbumName($album_name);
	$albumQuery->setImgMax('160c');
	$albumQueryURL = $albumQuery->getQueryUrl();
	
	try {
		 $albumEntry = $gp->getAlbumFeed($albumQueryURL);
	} catch (Exception $e) {
		 $albumEntry = new Zend_Gdata_Photos_AlbumEntry();
		 $albumEntry->setTitle($gp->newTitle(replace_bbcode($album_list[$gallery_id]['album']['title'][$current_album_idx])));
		 $albumEntry->setSummary($gp->newSummary(replace_bbcode($album_list[$gallery_id]['album']['summary'][$current_album_idx])));
		 $albumEntry->setGphotoAccess(new Zend_Gdata_Photos_Extension_Access('public'));
		 $albumEntry = $gp->insertAlbumEntry($albumEntry);
	}
	$albumURL = $albumEntry->getAlternateLink()->getHref();
	
	$result = '';

	foreach ($images[$gallery_id][$current_album]['image']['name'] as $key => $value) {
    	if ($images[$gallery_id][$current_album]['image']['hidden'][$key] == 'no') {
          if (empty($image_filter) 
            || ($image_filter['type'] == 'include' && in_array($value, $image_filter['filter']))
            || ($image_filter['type'] == 'exclude' && !in_array($value, $image_filter['filter']))
           ) {
				(array_key_exists('resizedName', $images[$gallery_id][$current_album]['image']) && array_key_exists($key, $images[$gallery_id][$current_album]['image']['resizedName'])) ? $name_key = 'resizedName' : $name_key = 'name';

				$image_link = sprintf('%s%s&filename=%s.%s', stripslashes($images[$gallery_id][$current_album]['baseurl']),
				                             $images[$gallery_id][$current_album]['image'][$name_key][$key],
				                             $images[$gallery_id][$current_album]['image'][$name_key][$key],
				                             $images[$gallery_id][$current_album]['image']['forceExtension'][$key]
				                    );

				$error = false;
				$error_count = 0;
				
				do {
					echo '===> image: ' . $images[$gallery_id][$current_album]['image'][$name_key][$key];
					echo " => downloading from gallery";
				
					// download image
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, $image_link);
					curl_setopt($ch, CURLOPT_HEADER, false);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					$image = curl_exec($ch);
					curl_close($ch);
	
					try {
						echo ' => uploading to picasa';
						$photoName = replace_bbcode($images[$gallery_id][$current_album]['image']['title'][$key]);
						$photoCaption = replace_bbcode($images[$gallery_id][$current_album]['image']['caption'][$key]);
		
						//$fd->setContentType("image/jpeg");
						$fd = new MyMediaVariableSource($image);
						$photoEntry = $gp->newPhotoEntry();				
						$photoEntry->setMediaSource($fd);
						$photoEntry->setTitle($gp->newTitle($photoName));
						$photoEntry->setSummary($gp->newSummary($photoCaption)); 
						
						$photoEntry = $gp->insertPhotoEntry($photoEntry, $albumQueryURL);
						
						$error = false;
						echo " - succesful\n";
					} catch (Exception $e) {
						$error = true;
						$error_count++;
						echo " -------> FAILED <-------\n";
					}
				} while ($error == true && $error_count < 10);
				
				if ($imagefilterActive) {
					if ($photoEntry->getLink() != null) {
						$linkArray = $photoEntry->getLink();

						$contentUrl = $linkArray[1]->getHref();
					}
					
					if ($photoEntry->getMediaGroup()->getThumbnail() != null) {
						$mediaThumbnailArray = $photoEntry->getMediaGroup()->getThumbnail();
						$firstThumbnailUrl = $mediaThumbnailArray[0]->getUrl();
						$thumbnailWidth = $mediaThumbnailArray[0]->getWidth();
						$thumbnailHeight = $mediaThumbnailArray[0]->getHeight();
					}

					$result.= sprintf('<a href="%s" target="_blank"><img src="%s" width="%s" height="%s" border="0"></a>',
										$contentUrl,
										$firstThumbnailUrl,
										$thumbnailWidth,
										$thumbnailHeight
									);
				}
           }
    	}
	}

	if (!$imagefilterActive) {
		$albumEntry = $gp->getAlbumEntry($albumQuery);
		$thumbnails = $albumEntry->getMediaGroup()->getThumbnail();
		$albumThumbnailURL = $thumbnails[0]->getUrl();
	
		$result = sprintf('<table style="width:194px;"><tr><td align="center" style="height:194px;background:url(http://picasaweb.google.com/f/img/transparent_album_background.gif) no-repeat left"><a href="%s" target="_blank"><img src="%s" width="160" height="160" style="margin:1px 0 0 4px;"></a></td></tr><tr><td style="text-align:center;font-family:arial,sans-serif;font-size:11px"><a href="%s" style="color:#4D4D4D;font-weight:bold;text-decoration:none;" target="_blank">%s</a></td></tr></table>',
							$albumURL,
							$albumThumbnailURL,
							$albumURL,
							$albumEntry->getTitle()->getText());
	}

	return $result;
}

function fetch_albums($root_album, $disable_caching = false) {
	global $galleries;
	global $album_list;
	
  $gallery_id = 0;
  $gallery = $galleries[$gallery_id];    
  
  if (!is_array($album_list[$gallery_id])) {
    $params = '&g2_form[cmd]=fetch-albums'
    				. '&g2_form[protocol_version]=2.0'
    				. '&g2_form[no_perms]=yes';

    $response = do_post_request($gallery['url'], $params);
    $album_list[$gallery_id] = parse_response($response);
  }

  // set root album, if not yet set
  if ($root_album == 0) {
    $arr_idx = array_search('0', $album_list[$gallery_id]['album']['parent']);
    $root_album = $album_list[$gallery_id]['album']['name'][$arr_idx];    
  }
  $album_list['root_album'] = $root_album;

  // set current album
  if (isset($_REQUEST['current_album'])) {
    $album_list['current_album'] = $_REQUEST['current_album'];
  } else {
    $album_list['current_album'] = $root_album;
  }
  
  // set index, title and parent of current album
  $album_list['current_album_idx'] = array_search($album_list['current_album'], $album_list[$gallery_id]['album']['name']);
  $album_list['current_album_title'] = $album_list[$gallery_id]['album']['title'][$album_list['current_album_idx']];
  if ($root_album == $album_list['current_album']) {
    $album_list['current_album_parent'] = $root_album;
  } else {
    $album_list['current_album_parent'] = $album_list[$gallery_id]['album']['parent'][$album_list['current_album_idx']];
  }
}

function do_post_request($url, $params = null) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url . '?g2_controller=remote:GalleryRemote');
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $response = curl_exec($ch);
  curl_close ($ch);

  return $response;
}

function parse_response($response) {
  $result = array();
  $lines = explode("\n", $response);

  foreach ($lines as $line) {
    if ($line{0} != '#') {
      list($key, $value) = explode('=', $line, 2);
      $keys = explode('.', $key);
      $p = &$result;
      foreach ($keys as $key) {
        if (!array_key_exists($key, $p)) { $p[$key] = array(); }
        $p = &$p[$key];
      }
      $p = stripslashes($value);
    }
  }

  return $result;
}

function fetch_images($current_album, $disable_caching = false) {
  global $images;
  global $galleries;
  
  $gallery_id = 0;
  $gallery = $galleries[$gallery_id];
  
  if (is_array($images[$gallery_id])) { 
    if (array_key_exists($current_album, $images[$gallery_id])) {
        return;
    }    
  }

  // fetch images
  $params = '&g2_form[cmd]=fetch-album-images'
  			. '&g2_form[protocol_version]=2.4'
  			. '&g2_form[albums_too]=no'
  			. '&g2_form[set_albumName]=' . $current_album;

  $response = do_post_request($gallery['url'], $params);
  $images = parse_response($response);

  $images[$gallery_id][$current_album] = $images;
}

function replace_bbcode($s) {
  // [b]
  $s = preg_replace('/\[b\]/i', '<strong>', $s);
  $s = preg_replace('/\[\/b\]/i', '</strong>', $s);
  
  // [i]
  $s = preg_replace('/\[i\]/i', '<i>', $s);
  $s = preg_replace('/\[\/i\]/i', '</i>', $s);
 
  // [list]
  $s = preg_replace('/\[list\]/i', '', $s);
  $s = preg_replace('/\[\/list\]/i', '', $s);
  
  // [*]
  $s = preg_replace('/\[\*\]/i', '<li>', $s);
  
  // [url]<url>[\url]
  $s = preg_replace('/\[url\](.+?)\[\/url\]/i', '<a href=\"$1\" target=\"_blank\">$1</a>', $s);
  
  // [url=<url>]<title>[\url]
  $s = preg_replace('/\[url=(.+?)\](.+?)\[\/url\]/i', '<a href=\"$1\" target=\"_blank\">$2</a>', $s);
  
  // [list]
  $s = preg_replace('/\[color=(.+?)\]/i', '<font color=\"$1\">', $s);
  $s = preg_replace('/\[\/color\]/i', '</font>', $s);
  
	// Quotes - not BB code but are needed as well :)
	$s = str_replace('"', '&quot;', $s);
  
  return $s;
}

?>