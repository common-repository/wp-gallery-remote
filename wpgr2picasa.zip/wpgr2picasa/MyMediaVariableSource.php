<?php

require_once 'Zend/Gdata/App/BaseMediaSource.php';

class MyMediaVariableSource extends Zend_Gdata_App_BaseMediaSource
{
	protected $_imageData = null;
	protected $_contentType = null;
	
	public function __construct($imageData, $contentType = 'image/jpeg')
    {
        $this->_imageData = $imageData;
        $this->_contentType = $contentType;
    }
    
    public function encode()
    {
    	return $this->_imageData;
    }
    
    public function getContentType()
    {
        return $this->_contentType;
    }
}

?>